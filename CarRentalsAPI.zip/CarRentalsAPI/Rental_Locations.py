
import requests
import pandas as pd

url = "https://tripadvisor16.p.rapidapi.com/api/v1/rentals/searchLocation"

search_term = input("Enter a search term: ")  # Prompt the user to enter a search term

querystring = {"query": search_term}


headers = {
    "X-RapidAPI-Key": "1025272456msh9187960ad11f174p1f03e2jsn2a9d094e8c85",
    "X-RapidAPI-Host": "tripadvisor16.p.rapidapi.com"
}

response = requests.get(url, headers=headers, params=querystring)
data = response.json()

if "data" in data:
    results = data["data"]
    data_list = []
    for result in results:
        geoID = result["geoId"]
        locationId = result["locationId"]
        localizedName = result["localizedName"]
        localizedAdditionalNames = result["localizedAdditionalNames"]
        locationV2 = result["locationV2"]
        placeType = result["placeType"]
        latitude = result["latitude"]
        longitude = result["longitude"]
        # Extract other desired information as needed
        data_list.append({
            "geoID": geoID,
            "LocationID": locationId,
            "LocalizedName": localizedName,
            "LocalizedAdditionalNames": localizedAdditionalNames,
            "locationV2": locationV2,
            "placeType": placeType,
            "latitude": latitude,
            "longitude": longitude
        })
    df = pd.DataFrame(data_list)
    print(df)

    # Export dataframe to CSV
    df.to_csv('output.csv', index=False)
    print("CSV file exported successfully.")
else:
    print("Error: Request failed with message", data["message"])