from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

url = "https://tripadvisor16.p.rapidapi.com/api/v1/rentals/searchLocation"

headers = {
    "X-RapidAPI-Key": "1025272456msh9187960ad11f174p1f03e2jsn2a9d094e8c85",
    "X-RapidAPI-Host": "tripadvisor16.p.rapidapi.com"
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['GET'])
def search_location():
    search_term = request.args.get('query')
    querystring = {"query": search_term}
    response = requests.get(url, headers=headers, params=querystring)
    data = response.json()
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)