import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class TripAdvisorRentalSearch {

    public static void main(String[] args) {
        String url = "https://tripadvisor16.p.rapidapi.com/api/v1/rentals/searchLocation";
        String apiKey = "1025272456msh9187960ad11f174p1f03e2jsn2a9d094e8c85";
        String apiHost = "tripadvisor16.p.rapidapi.com";

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a search term: ");
            String searchTerm = reader.readLine();

            String query = "query=" + searchTerm;
            URL apiUrl = new URL(url + "?" + query);

            HttpURLConnection conn = (HttpURLConnection) apiUrl.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("X-RapidAPI-Key", apiKey);
            conn.setRequestProperty("X-RapidAPI-Host", apiHost);

            int responseCode = conn.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader responseReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder responseBuilder = new StringBuilder();
                String line;
                while ((line = responseReader.readLine()) != null) {
                    responseBuilder.append(line);
                }
                responseReader.close();
                conn.disconnect();

                String jsonResponse = responseBuilder.toString();
                JSONObject data = new JSONObject(new JSONTokener(jsonResponse));

                if (data.has("data")) {
                    JSONArray results = data.getJSONArray("data");
                    JSONArray dataList = new JSONArray();

                    for (int i = 0; i < results.length(); i++) {
                        JSONObject result = results.getJSONObject(i);
                        String geoID = result.getString("geoId");
                        String locationId = result.getString("locationId");
                        String localizedName = result.getString("localizedName");
                        String localizedAdditionalNames = result.getString("localizedAdditionalNames");
                        String locationV2 = result.getString("locationV2");
                        String placeType = result.getString("placeType");
                        double latitude = result.getDouble("latitude");
                        double longitude = result.getDouble("longitude");

                        JSONObject dataItem = new JSONObject();
                        dataItem.put("geoID", geoID);
                        dataItem.put("LocationID", locationId);
                        dataItem.put("LocalizedName", localizedName);
                        dataItem.put("LocalizedAdditionalNames", localizedAdditionalNames);
                        dataItem.put("locationV2", locationV2);
                        dataItem.put("placeType", placeType);
                        dataItem.put("latitude", latitude);
                        dataItem.put("longitude", longitude);

                        dataList.put(dataItem);
                    }

                    // Save data to CSV file (replace this with your desired CSV handling)
                    System.out.println(dataList.toString());
                } else {
                    System.out.println("Error: Request failed with message " + data.optString("message"));
                }
            } else {
                System.out.println("Error: Request failed with response code " + responseCode);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}