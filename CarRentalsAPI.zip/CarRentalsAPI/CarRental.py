
import requests


url = "https://tripadvisor16.p.rapidapi.com/api/v1/cars/searchCarsSameDropOff"

# Prompt the user for input
pick_up_place_id = input("Enter the Pick-Up Place ID: ")
pick_up_location_type = input("Enter the Pick-Up Location Type: ")
pick_up_date = input("Enter the Pick-Up Date (YYYY-MM-DD): ")
drop_off_date = input("Enter the Drop-Off Date (YYYY-MM-DD): ")
pick_up_time = input("Enter the Pick-Up Time (HH:MM): ")
drop_off_time = input("Enter the Drop-Off Time (HH:MM): ")
order = input("Enter the Order: ")

querystring = {
    "pickUpPlaceId": pick_up_place_id,
    "pickUpLocationType": pick_up_location_type,
    "pickUpDate": pick_up_date,
    "dropOffDate": drop_off_date,
    "pickUpTime": pick_up_time,
    "dropOffTime": drop_off_time,
    "order": order,
    "page": "1",
    "currencyCode": "USD"
}

headers = {
    "X-RapidAPI-Key": "1025272456msh9187960ad11f174p1f03e2jsn2a9d094e8c85",
    "X-RapidAPI-Host": "tripadvisor16.p.rapidapi.com"
}

response = requests.get(url, headers=headers, params=querystring)

data = response.json()

# Extract specific information from the response
if "data" in data:
    results = data["data"]
    for result in results:
        name = result["name"]
        address = result["address"]
        # Extract other desired information as needed
        print(f"Name: {name}, Address: {address}")
else:
    print("Error: Request failed with message", data["message"])