$(document).ready(function() {
  $('#searchBtn').click(function() {
    var searchTerm = $('#searchTerm').val();
    if (searchTerm !== '') {
      $.ajax({
        url: 'search.py', // Path to your server-side script (e.g., Python file)
        method: 'POST',
        data: { search_term: searchTerm },
        success: function(response) {
          $('#results').html(response);
        },
        error: function(xhr, status, error) {
          console.log('Error:', error);
        }
      });
    }
  });
});